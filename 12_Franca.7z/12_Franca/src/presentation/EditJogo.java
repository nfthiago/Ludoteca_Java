/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package presentation;

import business.Artista;
import business.Autor;
import business.Categoria;
import business.Editora;
import business.Jogo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import persistence.DBManager;

/**
 *
 * @author Thiago
 */
public class EditJogo extends javax.swing.JDialog {
    
    public void preencherCampos(JTable tblJogos){
        int linha, copiasIndex, minIndex, maxIndex;
        
        
        linha = tblJogos.getSelectedRow();
        copiasIndex = Integer.parseInt((String)tblJogos.getValueAt(linha, 8)) -1;
        minIndex = Integer.parseInt((String)tblJogos.getValueAt(linha, 4)) -1;
        maxIndex = Integer.parseInt((String)tblJogos.getValueAt(linha, 5)) -1;
        
        try {
            //Instanciando o DBManager
            DBManager dbManager = new DBManager();
            
            //Instanciando ArrayLists de Autor, Artista, Editora, Categoria
            ArrayList<Autor> arrayAutores = new ArrayList<>();
            ArrayList<Artista> arrayArtistas = new ArrayList<>();
            ArrayList<Editora> arrayEditoras = new ArrayList<>();
            ArrayList<Categoria> arrayCategorias = new ArrayList<>();
            
            
            //Guardando o resultado dos métodos no objetos correspondentes
            arrayAutores = dbManager.buscarTodosAutores();
            arrayArtistas = dbManager.buscarTodosArtistas();
            arrayEditoras = dbManager.buscarTodasEditoras();
            arrayCategorias = dbManager.buscarTodasCategorias();
            
            //ciclo para guardar os autores na combobox
            for (Autor arrayAutor : arrayAutores) {
                cbbAutor.addItem(arrayAutor.getNomeAutor());
               
            }
            
            //ciclo para guardar os artistas na combobox
            for (Artista arrayArtista : arrayArtistas) {
                cbbArtista.addItem(arrayArtista.getNomeArtista());
            }
            
            //ciclo para guardar as editoras na combobox
            for (Editora arrayEditora : arrayEditoras) {
                cbbEditora.addItem(arrayEditora.getNomeEditora());
            }
            
            //ciclo para guardar as categorias na combobox
            for (Categoria arrayCategoria : arrayCategorias){
                cbbCategoria.addItem(arrayCategoria.getNomeCategoria());
            }
            
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(InsertJogo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        cbbAutor.setSelectedItem((String) tblJogos.getValueAt(linha, 1));
        cbbArtista.setSelectedItem((String) tblJogos.getValueAt(linha, 2));
        cbbEditora.setSelectedItem((String) tblJogos.getValueAt(linha, 3));
        txtNomeJogo.setText((String)tblJogos.getValueAt(linha, 0));
        cbbQtdCopias.setSelectedIndex(copiasIndex);
        cbbNumMin.setSelectedIndex(minIndex);
        cbbNumMax.setSelectedIndex(maxIndex);
        txtData.setText((String) tblJogos.getValueAt(linha, 6));
        txtAreaDescricao.setText((String)tblJogos.getValueAt(linha, 7));
        
              
        try {
            DBManager dbManager = new DBManager();
            Jogo jogo = new Jogo();
            jogo = dbManager.buscarJogo((String)tblJogos.getValueAt(linha, 0));
            System.out.println(jogo.getPrecoCompra());
            spnPreco.setValue(jogo.getPrecoCompra());
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(EditJogo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
        
    }
    
    
    private String nomeJogo;
    /**
     * Creates new form EditJogo
     */
    public EditJogo(java.awt.Frame parent, boolean modal, JTable tblJogos) {
        super(parent, modal);
        initComponents();
        
        int linha = tblJogos.getSelectedRow();
        nomeJogo = (String)tblJogos.getValueAt(linha, 0);
        
        try {
            //Instanciando o DBManager
            DBManager dbManager = new DBManager();
            
            //Instanciando ArrayLists de Categoria
            ArrayList<Categoria> arrayCategorias = new ArrayList<>();
            
            //Guardando o resultado do método no objeto correspondente
            arrayCategorias = dbManager.buscarTodasCategorias();
            
            //ciclo para guardar os autores na combobox
             for (Categoria arrayCategoria : arrayCategorias){
                cbbCategoria.addItem(arrayCategoria.getNomeCategoria());
            }
            
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(EditJogo.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
        
       
        preencherCampos(tblJogos);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtData = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblNumJog = new javax.swing.JLabel();
        lblNumMin = new javax.swing.JLabel();
        cbbNumMin = new javax.swing.JComboBox<>();
        lblNumMax = new javax.swing.JLabel();
        cbbNumMax = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        lblNomeJogo = new javax.swing.JLabel();
        txtNomeJogo = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        lblAutor = new javax.swing.JLabel();
        cbbAutor = new javax.swing.JComboBox<>();
        lblCategoria = new javax.swing.JLabel();
        cbbCategoria = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        lblArtista = new javax.swing.JLabel();
        cbbArtista = new javax.swing.JComboBox<>();
        lblEditora = new javax.swing.JLabel();
        cbbEditora = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        lblQtd = new javax.swing.JLabel();
        lblPreco = new javax.swing.JLabel();
        cbbQtdCopias = new javax.swing.JComboBox<>();
        spnPreco = new javax.swing.JSpinner();
        jPanel6 = new javax.swing.JPanel();
        btnAtualizaJogo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaDescricao = new javax.swing.JTextArea();
        lblDescricao = new javax.swing.JLabel();
        lblData = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtData.setText("2000");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/support/gameInsertEdit.png"))); // NOI18N

        lblNumJog.setText("Número de jogadores");

        lblNumMin.setText("Mínimo:");

        cbbNumMin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));

        lblNumMax.setText("Máximo:");

        cbbNumMax.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10+", " " }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNumJog)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblNumMin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblNumMax))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cbbNumMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbbNumMax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(lblNumJog)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNumMin)
                    .addComponent(lblNumMax))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbNumMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbNumMax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        lblNomeJogo.setText("Nome do jogo:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNomeJogo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNomeJogo, javax.swing.GroupLayout.DEFAULT_SIZE, 319, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(txtNomeJogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(lblNomeJogo))
        );

        lblAutor.setText("Qual o autor principal do jogo?");

        lblCategoria.setText("Qual a categoria do jogo?");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblAutor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(cbbAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCategoria)
                            .addComponent(cbbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(lblAutor)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbbAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCategoria)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        lblArtista.setText("Qual o artista principal do jogo?");

        lblEditora.setText("Qual a editora do jogo?");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblArtista))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbbArtista, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblEditora)
                            .addComponent(cbbEditora, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(lblArtista)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbbArtista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEditora)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbbEditora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        lblQtd.setText("Número de cópias:");

        lblPreco.setText("Preço de mercado:");

        cbbQtdCopias.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10+", " " }));

        spnPreco.setModel(new javax.swing.SpinnerNumberModel(0.0d, null, null, 0.5d));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(lblPreco)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(spnPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(lblQtd)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbbQtdCopias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbQtdCopias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblQtd))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPreco)
                    .addComponent(spnPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 10, Short.MAX_VALUE))
        );

        btnAtualizaJogo.setText("Atualizar");
        btnAtualizaJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizaJogoActionPerformed(evt);
            }
        });

        txtAreaDescricao.setColumns(20);
        txtAreaDescricao.setLineWrap(true);
        txtAreaDescricao.setRows(5);
        jScrollPane1.setViewportView(txtAreaDescricao);

        lblDescricao.setText("Breve descrição:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAtualizaJogo)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblDescricao)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 494, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addComponent(lblDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAtualizaJogo))
        );

        lblData.setText("Ano de lançamento:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(55, 55, 55)
                                .addComponent(lblData)
                                .addGap(8, 8, 8)
                                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(35, 35, 35)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 28, Short.MAX_VALUE))
            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblData, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtualizaJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizaJogoActionPerformed
        
        String novoNome;
        String autorJogo;
        String artistaJogo;
        String editoraJogo;
        String categoriaJogo;
        String numMin;
        String numMax;
        String dataJogo;
        String qtdJogo;
        String precoJogo;
        String descricaoJogo;
        int codAutor;
        int codArtista;
        int codEditora;
        int dataInt;
        int numMinInt;
        int numMaxInt;
        int qtdJogoInt;
        

        novoNome = txtNomeJogo.getText();
        autorJogo = cbbAutor.getModel().getSelectedItem().toString();
        artistaJogo = cbbArtista.getModel().getSelectedItem().toString();
        editoraJogo = cbbEditora.getModel().getSelectedItem().toString();
        categoriaJogo = cbbCategoria.getModel().getSelectedItem().toString();
        numMin = cbbNumMin.getModel().getSelectedItem().toString();
        numMinInt = Integer.parseInt(numMin);
        numMax = cbbNumMax.getModel().getSelectedItem().toString();
        numMaxInt = Integer.parseInt(numMax);

        dataJogo = txtData.getText();
        dataInt = Integer.parseInt(dataJogo);
        qtdJogo = cbbQtdCopias.getModel().getSelectedItem().toString();
        qtdJogoInt = Integer.parseInt(qtdJogo);
        precoJogo = spnPreco.getModel().getValue().toString();
        Double precoDouble = Double.valueOf(precoJogo);

        descricaoJogo = txtAreaDescricao.getText();

        try {
            DBManager dbManager = new DBManager();

            codAutor = dbManager.buscarAutor(autorJogo).getId();
            codArtista = dbManager.buscarArtista(artistaJogo).getId();
            codEditora = dbManager.buscarEditora(editoraJogo).getId();

            Jogo jogo = new Jogo(novoNome, codAutor, codArtista, codEditora, numMinInt, numMaxInt, dataInt, descricaoJogo ,qtdJogoInt, precoDouble);

            if(dbManager.alterarJogo(dbManager.buscarJogo(nomeJogo), novoNome, codAutor, codArtista, codEditora, numMinInt, numMaxInt, dataInt, descricaoJogo, qtdJogoInt, precoDouble) != 0){
                JOptionPane.showMessageDialog(rootPane, "Jogo alterado com sucesso!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
                
            } else {
                JOptionPane.showMessageDialog(rootPane,"Atenção, Jogo não alterado!", "Janela de erro", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(InsertJogo.class.getName()).log(Level.SEVERE, null, ex);
        }

        dispose();

    }//GEN-LAST:event_btnAtualizaJogoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditJogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditJogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditJogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditJogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizaJogo;
    private javax.swing.JComboBox<String> cbbArtista;
    private javax.swing.JComboBox<String> cbbAutor;
    private javax.swing.JComboBox<String> cbbCategoria;
    private javax.swing.JComboBox<String> cbbEditora;
    private javax.swing.JComboBox<String> cbbNumMax;
    private javax.swing.JComboBox<String> cbbNumMin;
    private javax.swing.JComboBox<String> cbbQtdCopias;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblArtista;
    private javax.swing.JLabel lblAutor;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblData;
    private javax.swing.JLabel lblDescricao;
    private javax.swing.JLabel lblEditora;
    private javax.swing.JLabel lblNomeJogo;
    private javax.swing.JLabel lblNumJog;
    private javax.swing.JLabel lblNumMax;
    private javax.swing.JLabel lblNumMin;
    private javax.swing.JLabel lblPreco;
    private javax.swing.JLabel lblQtd;
    private javax.swing.JSpinner spnPreco;
    private javax.swing.JTextArea txtAreaDescricao;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtNomeJogo;
    // End of variables declaration//GEN-END:variables
}
