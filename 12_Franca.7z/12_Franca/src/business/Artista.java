/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business;

import java.util.Objects;

/**
 *
 * @author Thiago
 */
public class Artista {
    
    private int id;
    private String nomeArtista;

    public Artista() {
    }

    public Artista(String nomeArtista) {
        this.nomeArtista = nomeArtista;
    }

    
    public Artista(int id, String nomeArtista) {
        this.id = id;
        this.nomeArtista = nomeArtista;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeArtista() {
        return nomeArtista;
    }

    public void setNomeArtista(String nomeArtista) {
        this.nomeArtista = nomeArtista;
    }

    @Override
    public String toString() {
        return "Artista{" + "id=" + id + ", nomeArtista=" + nomeArtista + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.id;
        hash = 97 * hash + Objects.hashCode(this.nomeArtista);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Artista other = (Artista) obj;
        if (this.id != other.id) {
            return false;
        }
        return Objects.equals(this.nomeArtista, other.nomeArtista);
    }
    
    
    
}
