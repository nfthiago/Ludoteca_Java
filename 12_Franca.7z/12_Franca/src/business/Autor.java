/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Thiago
 */
public class Autor {
    
    private int id;
    private String nomeAutor;
    

    /**
     *
     */
    public Autor(String nomeAutor) {    
        this.nomeAutor = nomeAutor;
    }

    public Autor(int id, String nomeAutor) {
        this.id = id;
        this.nomeAutor = nomeAutor;
    }

    public Autor() {
    }
    
    
    
    

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getNomeAutor() {
        return nomeAutor;
    }

    /**
     *
     * @param nomeAutor
     */
    public void setNomeAutor(String nomeAutor) {
        this.nomeAutor = nomeAutor;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Autor{" + "id=" + id + ", nomeAutor=" + nomeAutor + '}';
    }

    /**
     *
     * @return
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + this.id;
        hash = 53 * hash + Objects.hashCode(this.nomeAutor);
        return hash;
    }

    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Autor other = (Autor) obj;
        if (this.id != other.id) {
            return false;
        }
        return Objects.equals(this.nomeAutor, other.nomeAutor);
    }
    
    
    
}
