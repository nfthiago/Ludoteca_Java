/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.util.Objects;

/**
 *
 * @author Thiago França
 */
public class Jogo {
    
    private int id;
    private String nome;
    private int codAutor;
    private int codArtista;
    private int codEditora;
    private int numJogadorMin;
    private int numJogadorMax;
    private int dataLancamento;
    private String descricao;
    private int qtdCopias;
    private double precoCompra;
    private String imagem;
    private String arquivo;

    /**
     *
     * @param id
     */
    public Jogo(int id) {
        this.id = id;
    }

    public Jogo(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public Jogo() {
    }

    public Jogo(int id, String nome, String imagem, Double preco) {
        this.id = id;
        this.nome = nome;
        this.imagem = imagem;
        this.precoCompra = preco;
    }

     public Jogo(int id, String nome, String imagem) {
        this.id = id;
        this.nome = nome;
        this.imagem = imagem;
    }
    
    public Jogo(String nome, int codAutor, int codArtista, int codEditora, int numJogadorMin, int numJogadorMax, int dataLancamento, String descricao, int qtdCopias, double precoCompra) {
        this.nome = nome;
        this.codAutor = codAutor;
        this.codArtista = codArtista;
        this.codEditora = codEditora;
        this.numJogadorMin = numJogadorMin;
        this.numJogadorMax = numJogadorMax;
        this.dataLancamento = dataLancamento;
        this.descricao = descricao;
        this.qtdCopias = qtdCopias;
        this.precoCompra = precoCompra;
    }

    
    
    
    
    

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getNome() {
        return nome;
    }

    /**
     *
     * @param nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     *
     * @return
     */
    public int getCodAutor() {
        return codAutor;
    }

    /**
     *
     * @param codAutor
     */
    public void setCodAutor(int codAutor) {
        this.codAutor = codAutor;
    }

    /**
     *
     * @return
     */
    public int getCodArtista() {
        return codArtista;
    }

    /**
     *
     * @param codArtista
     */
    public void setCodArtista(int codArtista) {
        this.codArtista = codArtista;
    }

    /**
     *
     * @return
     */
    public int getCodEditora() {
        return codEditora;
    }

    /**
     *
     * @param codEditora
     */
    public void setCodEditora(int codEditora) {
        this.codEditora = codEditora;
    }

    /**
     *
     * @return
     */
    public int getNumJogadorMin() {
        return numJogadorMin;
    }

    /**
     *
     * @param numJogadorMin
     */
    public void setNumJogadorMin(int numJogadorMin) {
        this.numJogadorMin = numJogadorMin;
    }

    /**
     *
     * @return
     */
    public int getNumJogadorMax() {
        return numJogadorMax;
    }

    /**
     *
     * @param numJogadorMax
     */
    public void setNumJogadorMax(int numJogadorMax) {
        this.numJogadorMax = numJogadorMax;
    }

    /**
     *
     * @return
     */
    public int getDataLancamento() {
        return dataLancamento;
    }

    /**
     *
     * @param dataLancamento
     */
    public void setDataLancamento(int dataLancamento) {
        this.dataLancamento = dataLancamento;
    }

    /**
     *
     * @return
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     *
     * @param descricao
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     *
     * @return
     */
    public int getQtdCopias() {
        return qtdCopias;
    }

    /**
     *
     * @param qtdCopias
     */
    public void setQtdCopias(int qtdCopias) {
        this.qtdCopias = qtdCopias;
    }

    /**
     *
     * @return
     */
    public double getPrecoCompra() {
        return precoCompra;
    }

    /**
     *
     * @param precoCompra
     */
    public void setPrecoCompra(double precoCompra) {
        this.precoCompra = precoCompra;
    }

    /**
     *
     * @return
     */
    public String getImagem() {
        return imagem;
    }

    /**
     *
     * @param imagem
     */
    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    /**
     *
     * @return
     */
    public String getArquivo() {
        return arquivo;
    }

    /**
     *
     * @param arquivo
     */
    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    @Override
    public String toString() {
        return "Jogo{" + "id=" + id + ", nome=" + nome + ", codAutor=" + codAutor + ", codArtista=" + codArtista + ", codEditora=" + codEditora + ", numJogadorMin=" + numJogadorMin + ", numJogadorMax=" + numJogadorMax + ", dataLancamento=" + dataLancamento + ", descricao=" + descricao + ", qtdCopias=" + qtdCopias + ", precoCompra=" + precoCompra + ", imagem=" + imagem + ", arquivo=" + arquivo + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + this.id;
        hash = 17 * hash + Objects.hashCode(this.nome);
        hash = 17 * hash + this.codAutor;
        hash = 17 * hash + this.codArtista;
        hash = 17 * hash + this.codEditora;
        hash = 17 * hash + this.numJogadorMin;
        hash = 17 * hash + this.numJogadorMax;
        hash = 17 * hash + this.dataLancamento;
        hash = 17 * hash + Objects.hashCode(this.descricao);
        hash = 17 * hash + this.qtdCopias;
        hash = 17 * hash + (int) (Double.doubleToLongBits(this.precoCompra) ^ (Double.doubleToLongBits(this.precoCompra) >>> 32));
        hash = 17 * hash + Objects.hashCode(this.imagem);
        hash = 17 * hash + Objects.hashCode(this.arquivo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Jogo other = (Jogo) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.codAutor != other.codAutor) {
            return false;
        }
        if (this.codArtista != other.codArtista) {
            return false;
        }
        if (this.codEditora != other.codEditora) {
            return false;
        }
        if (this.numJogadorMin != other.numJogadorMin) {
            return false;
        }
        if (this.numJogadorMax != other.numJogadorMax) {
            return false;
        }
        if (this.dataLancamento != other.dataLancamento) {
            return false;
        }
        if (this.qtdCopias != other.qtdCopias) {
            return false;
        }
        if (Double.doubleToLongBits(this.precoCompra) != Double.doubleToLongBits(other.precoCompra)) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.imagem, other.imagem)) {
            return false;
        }
        if (!Objects.equals(this.arquivo, other.arquivo)) {
            return false;
        }
        return true;
    }
    
    
    

}
