/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business;

import java.util.Objects;

/**
 *
 * @author Thiago
 */
public class Editora {
    
    private int id;
    private String nomeEditora;

    public Editora() {
    }

    public Editora(String nomeEditora) {
        this.nomeEditora = nomeEditora;
    }

    
    public Editora(int id, String nomeEditora) {
        this.id = id;
        this.nomeEditora = nomeEditora;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeEditora() {
        return nomeEditora;
    }

    public void setNomeEditora(String nomeEditora) {
        this.nomeEditora = nomeEditora;
    }

    @Override
    public String toString() {
        return "Editora{" + "id=" + id + ", nomeEditora=" + nomeEditora + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + this.id;
        hash = 37 * hash + Objects.hashCode(this.nomeEditora);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Editora other = (Editora) obj;
        if (this.id != other.id) {
            return false;
        }
        return Objects.equals(this.nomeEditora, other.nomeEditora);
    }
    
    
    
}
