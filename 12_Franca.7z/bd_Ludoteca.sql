-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: 192.168.56.110    Database: ludoteca
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artista`
--

DROP TABLE IF EXISTS `artista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artista` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeArtista` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artista`
--

LOCK TABLES `artista` WRITE;
/*!40000 ALTER TABLE `artista` DISABLE KEYS */;
INSERT INTO `artista` VALUES (1,'Ian O`Toole'),(2,'Gavan Brown'),(3,'Kevin Childress'),(4,'Doris Matthäus'),(5,'Klemens Franz'),(6,'Philippe Guérin'),(7,'Jakub Rozalski'),(8,'Mariano Iannelli'),(9,'Mike Atkinson'),(10,'Cristi Balanescu'),(11,'Dennis Crabapple McClain'),(12,' Matt Allsopp');
/*!40000 ALTER TABLE `artista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autor`
--

DROP TABLE IF EXISTS `autor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeAutor` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autor`
--

LOCK TABLES `autor` WRITE;
/*!40000 ALTER TABLE `autor` DISABLE KEYS */;
INSERT INTO `autor` VALUES (1,'Vital Lacerda'),(2,'Martin Wallace'),(3,'Corey Konieczka'),(4,'Klaus-Jürgen Wrede'),(5,'Uwe Rosenberg'),(6,'Michael Kiesling'),(7,'Jamey Stegmaier'),(8,'Nikki Valens'),(9,'Rob Daviau');
/*!40000 ALTER TABLE `autor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeCategoria` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Estratégia'),(2,'Colocação de peças'),(3,'Gestão de mão'),(4,'Controle de área'),(5,'Gestão economica'),(6,'Construção de rotas'),(7,'Construção de cidade'),(8,'Gerenciamento de recursos'),(9,'Narrativa'),(10,'Gestão de cartas'),(11,'Especulação financeira'),(12,'Terror'),(13,'Dungeon Crawler'),(14,'Rolagem de dados');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `editora`
--

DROP TABLE IF EXISTS `editora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `editora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeEditora` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `editora`
--

LOCK TABLES `editora` WRITE;
/*!40000 ALTER TABLE `editora` DISABLE KEYS */;
INSERT INTO `editora` VALUES (1,'Eagle-Gryphon Games'),(2,'Roxley'),(3,'Fantasy Flight Games'),(5,'Hans im Glück'),(6,'Lookout Games'),(7,'Next Move Games'),(8,'Stonemaier Games'),(9,'Whats Your Game?'),(10,' PHALANX'),(11,'Avalon Hill');
/*!40000 ALTER TABLE `editora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jogo`
--

DROP TABLE IF EXISTS `jogo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jogo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeJogo` varchar(250) DEFAULT NULL,
  `codAutor` int NOT NULL,
  `codArtista` int NOT NULL,
  `codEditora` int NOT NULL,
  `numJogadorMin` int NOT NULL,
  `numJogadorMax` int NOT NULL,
  `dataLancamento` int NOT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `qtdCopias` int NOT NULL,
  `precoCompra` double NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `arquivo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codAutor` (`codAutor`),
  KEY `codArtista` (`codArtista`),
  KEY `codEditora` (`codEditora`),
  CONSTRAINT `jogo_ibfk_1` FOREIGN KEY (`codAutor`) REFERENCES `autor` (`id`),
  CONSTRAINT `jogo_ibfk_2` FOREIGN KEY (`codArtista`) REFERENCES `artista` (`id`),
  CONSTRAINT `jogo_ibfk_3` FOREIGN KEY (`codEditora`) REFERENCES `editora` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogo`
--

LOCK TABLES `jogo` WRITE;
/*!40000 ALTER TABLE `jogo` DISABLE KEYS */;
INSERT INTO `jogo` VALUES (1,'Lisboa',1,1,1,1,4,2017,'Lisboa é um jogo sobre a reconstrução de Lisboa após o terremoto de 1755.',1,53.89,'https://tinyurl.com/2p99jp5f',NULL),(2,'Brass: Lancashire',2,2,2,2,4,2007,'Brass é um jogo de estratégia econômica que conta a história de empresários de algodão concorrentes em Lancashire durante a revolução industrial.',1,67.43,'https://tinyurl.com/bdhvr3n2',NULL),(3,'\nBattlestar Galactica: The Board Game',3,3,3,3,6,2008,'Cada um joga com um personagem da série, divididos em 4 grupos: Líder Político, Líder Militar, Piloto e Suporte.',1,125,'https://tinyurl.com/ypm9jzhk',NULL),(6,'Carcassonne',4,4,5,2,5,2000,'Carcassonne é um jogo de colocação de peças modulares, onde cada ladrilho representam um pedaço do sul da França. \nCada jogada consiste em compra e colocar uma nova peça, que precisa ser encaixada preservando as formas topológicas dos desenhos. \nCada peça irá expandir o tabuleiro e você deve tentar controlar áreas como uma cidade (Cavaleiro), uma estrada (Ladrão), um mosteiro (Monge) ou dos campos (Fazendeiros) para ganhar pontos.',3,29,NULL,NULL),(7,'Agricola',5,5,6,1,5,2007,'Em Agricola, você é um fazendeiro em um barraco de madeira com seu cônjuge e um pouco mais. \nEm um turno, você começa a ter apenas duas ações, um para você e um para o cônjuge, de todas as possibilidades que você encontrará em uma fazenda: recolher barro, madeira ou pedra, cercas de construção, e assim por diante.',2,32.5,NULL,NULL),(8,'Azul',6,6,7,2,4,2017,'No jogo, os jogadores se revezam, comprando tiles coloridos dos fornecedores para seu próprio tabuleiro.\nMais tarde na rodada, os jogadores marcam pontos com base em como eles colocaram seus azulejos para decorar o palácio. \nPontos extras são pontuados para padrões específicos e conjuntos completos; os suprimentos desperdiçados danificam a pontuação do jogador. \nGanha o jogador com mais pontos no final do jogo.',3,30,NULL,NULL),(9,'Scythe',7,7,8,1,5,2016,'Em Scythe, cada jogador representa um Herói tentando fazer a sua facção a mais rica e poderosa. \nOs jogadores exploram e conquistam territórios; recrutam novos recrutas; produzem recursos e trabalhadores; constroem estruturas; e enviam para o campo de batalha monstruosas máquinas de guerra conhecidas como Mechas.',1,52.5,NULL,NULL),(10,'Vinhos',1,8,1,2,4,2010,'Em Vinhos, você vai desempenhar o papel de produtores de vinho em Portugal.\nDurante um período de seis anos, você vai expandir o seu negócio, estabelecendo Vinículas nas diferentes regiões de Portugal, a compra de vinhas e construção de adegas. \nEnólogos qualificados irão ajudá-lo a aumentar a qualidade do seu vinho, enquanto que os maiores especialistas de vinhos irão aumentar seus recursos na \"Feira Nacional do Vinho Português\", a Feira de degustação de vinhos.',1,45,NULL,NULL),(11,'Automobile',2,9,10,3,5,2009,'Um jogo puramente econômico, no melhor estilo \"Martin Wallace\". \nCom um inteligente mecanismo de seleção de papéis, demanda variável toda rodada, você precisa vender carros populares, de classe média ou luxo.\n\nAo longo do jogo você fecha fábricas e abre novas com modelos mais modernos. No final, quem tiver juntado mais dinheiro vence.',1,26.9,NULL,NULL),(12,'A Study in Emerald (second edition)',2,1,10,2,5,2015,'O jogo A Study in Emerald tira sua trama central do conto premiado escrito por Neil Gaiman, em que os mundos de Sherlock Holmes e HP Lovecraft são combinados. \nNo entanto, para criar um mundo detalhado o suficiente para os jogadores, muito tem sido adicionado a partir da história original. \nO século XIX foi um tempo de agitação, com muitos personagens coloridos lutando a favor e contra as autoridades. \nA Study in Emerald é o resultado da fusão destes três mundos.',1,49.9,NULL,NULL),(13,'Mansions of Madness (2ª Edição)',8,10,3,1,5,2016,'Mansions of Madness: Second Edition é um jogo de tabuleiro totalmente cooperativo, orientado por um aplicativo, de horror e mistério para um a cinco jogadores que ocorre no mesmo universo de Eldritch Horror e Elder Sign. \nDeixe o app envolvente guiá-lo pelas ruas veladas de Innsmouth e os corredores assombrados de mansões amaldiçoadas de Arkham enquanto você procura por respostas e descanso.',1,59.9,NULL,NULL),(14,'Betrayal at House on the Hill',9,11,11,3,6,2004,'Betrayal at House on the Hill constrói rapidamente suspense e emoção quando os jogadores exploram uma mansão assombrada de sua própria concepção, encontrando espíritos e presságios assustadores que predizem seu destino. \nCom cerca de uma hora no tempo de jogo, Betrayal at House on the Hill é ideal para festas, reuniões de família ou diversão casual com os amigos.',1,39.9,NULL,NULL),(15,'Star Wars: Rebellion',3,12,3,2,4,2016,'Experimente a Guerra Civil Galática como nunca antes. \nEm Star Wars: Rebellion, você controla todo o Império Galático ou a Aliança Rebelde. \nVocê precisa comandar naves espaciais, considerar movimentação de tropas, e agrupar sistemas para sua causa. \nDadas as diferenças entre o Império e a Aliança Rebelde, cada lado tem diferentes condições de vitória, e será necessário adaptar o estilo de jogo dependendo de quem você irá representar.',1,65,NULL,NULL);
/*!40000 ALTER TABLE `jogo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jogoCategoria`
--

DROP TABLE IF EXISTS `jogoCategoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jogoCategoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codJogo` int NOT NULL,
  `codCategoria` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codJogo` (`codJogo`),
  KEY `codCategoria` (`codCategoria`),
  CONSTRAINT `jogoCategoria_ibfk_1` FOREIGN KEY (`codJogo`) REFERENCES `jogo` (`id`),
  CONSTRAINT `jogoCategoria_ibfk_2` FOREIGN KEY (`codCategoria`) REFERENCES `categoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogoCategoria`
--

LOCK TABLES `jogoCategoria` WRITE;
/*!40000 ALTER TABLE `jogoCategoria` DISABLE KEYS */;
INSERT INTO `jogoCategoria` VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,3),(5,2,5),(6,2,6),(7,3,1);
/*!40000 ALTER TABLE `jogoCategoria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 10:19:36
